
/* ------------------- Resource Compiler Header File -------------------- */

/*  This file supplies the constants used by the resource compiler for
          various 32 bit resource components in .RC script files. */

/* ---------------------------------------------------------------------- */

    
#define IDC_BUTTON64	102
#define IDC_BUTTON63	101
#define IDC_BUTTON62	101
#define IDC_BUTTON61	103
#define IDC_BUTTON60	102
#define IDC_GROUPBOX11	101
#define IDC_BUTTON59	102
#define IDC_BUTTON58	102
#define IDC_BUTTON57	101
#define IDC_BUTTON56	101
#define IDC_EDIT29	114
#define IDC_EDIT28	113
#define IDC_GROUPBOX10	112
#define IDC_GROUPBOX9	111
#define IDC_LISTBOX2	110
#define IDC_MSCTLS_STATUSBAR7	109
#define IDC_BUTTON55	108
#define IDC_RADIOBUTTON11	107
#define IDC_RADIOBUTTON10	106
#define IDC_GROUPBOX8	105
#define IDC_RADIOBUTTON9	104
#define IDC_RADIOBUTTON8	103
#define IDC_RADIOBUTTON7	102
#define IDC_GROUPBOX7	101
#define IDC_BUTTON54	102
#define IDC_BUTTON53	101
#define IDC_GROUPBOX6	104
#define IDC_EDIT27	103
#define IDC_GROUPBOX5	102
#define IDC_EDIT26	101
#define DIALOG_3	3
#define IDC_EDIT25	101
#define CM_POPUPITEM2	62720
#define CM_POPUPITEM1	62532
#define CM_UTILIDADESPOPUP1	62720
#define MENUEX_2	2
#define BITMAP_1	1
#define IDC_RICHEDIT1	101
#define IDC_RADIOBUTTON6	105
#define IDC_RADIOBUTTON5	104
#define IDC_RADIOBUTTON4	103
#define IDC_RADIOBUTTON3	102
#define IDC_RADIOBUTTON1	101
#define DIALOG_2	2
#define IDC_STATUSBAR6	136
#define IDC_MSCTLS_STATUSBAR6	136
#define IDC_STATUSBAR5	135
#define IDC_MSCTLS_STATUSBAR5	135
#define IDC_STATUSBAR4	134
#define IDC_MSCTLS_STATUSBAR4	134
#define IDC_GROUPBOX4	133
#define IDC_CHECKBOX2	132
#define IDC_CHECKBOX1	131
#define IDC_STATUSBAR3	130
#define IDC_STATUSBAR2	128
#define IDC_MSCTLS_STATUSBAR3	130
#define IDC_MSCTLS_STATUSBAR2	128
#define IDC_RADIOBUTTON2	3049
#define IDC_GROUPBOX3	130
#define IDC_STATUSBAR1	129
#define IDC_MSCTLS_STATUSBAR1	129
#define IDC_BUTTON52	102
#define IDC_BUTTON51	101
#define DIALOG_1	1
#define IDC_GROUPBOX2	128
#define IDC_GROUPBOX1	128
#define IDC_MSCTLS_UPDOWN4	120
#define IDC_MSCTLS_UPDOWN3	102
#define IDC_UPDOWN1	102
#define IDC_MSCTLS_UPDOWN2	102
#define IDC_TOOLBAR8	109
#define IDC_TOOLBAR7	108
#define IDC_TOOLBAR6	107
#define IDC_TOOLBAR5	106
#define IDC_TOOLBAR4	105
#define IDC_TOOLBARWINDOW8	109
#define IDC_TOOLBARWINDOW7	108
#define IDC_TOOLBARWINDOW6	107
#define IDC_TOOLBARWINDOW5	106
#define IDC_TOOLBARWINDOW4	105
#define IDC_TOOLBAR3	104
#define IDC_TOOLBARWINDOW3	104
#define IDC_TOOLBAR2	103
#define IDC_TOOLBARWINDOW2	103
#define IDC_MSCTLS_UPDOWN1	103
#define IDC_TOOLBAR1	101
#define IDC_BUTTON50	102
#define IDC_TOOLBAR	101
#define IDC_TOOLBARWINDOW1	101
    #define WM_DDE_INITIATE     	(WM_DDE_FIRST)
    #define WM_DDE_TERMINATE    	(WM_DDE_FIRST+1)
    #define WM_DDE_ADVISE	    	(WM_DDE_FIRST+2)
    #define WM_DDE_UNADVISE     	(WM_DDE_FIRST+3)
    #define WM_DDE_ACK          	(WM_DDE_FIRST+4)
    #define WM_DDE_DATA         	(WM_DDE_FIRST+5)
    #define WM_DDE_REQUEST		(WM_DDE_FIRST+6)
    #define WM_DDE_POKE         	(WM_DDE_FIRST+7)
    #define WM_DDE_EXECUTE	    	(WM_DDE_FIRST+8)
    #define WM_DDE_LAST         	(WM_DDE_FIRST+8)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
/* --------------------- Common Control Styles ------------------------- */

    #define CCS_TOP                 0x00000001L
    #define CCS_NOMOVEY             0x00000002L
    #define CCS_BOTTOM              0x00000003L
    #define CCS_NORESIZE            0x00000004L
    #define CCS_NOPARENTALIGN       0x00000008L
    #define CCS_ADJUSTABLE          0x00000020L
    #define CCS_NODIVIDER           0x00000040L
    #define CCS_VERT                0x00000080L
    #define CCS_LEFT                (CCS_VERT | CCS_TOP)
    #define CCS_RIGHT               (CCS_VERT | CCS_BOTTOM)
    #define CCS_NOMOVEX             (CCS_VERT | CCS_NOMOVEY)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /* style definition */

    
    
    
    
    

    /* ShowWindow() Commands */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*
     * Old ShowWindow() Commands
     */
    
    
    
    
    
    
    /*
     * Identifiers for the WM_SHOWWINDOW message
     */
    
    
    
    
    
    /*
     * Virtual Keys, Standard Set
     */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /* VK_0 thru VK_9 are the same as ASCII '0' thru '9' (0x30 - 0x39) */
    /* VK_A thru VK_Z are the same as ASCII 'A' thru 'Z' (0x41 - 0x5A) */
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /* WM_ACTIVATE state values */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #define WM_SETTINGCHANGE                WM_WININICHANGE
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /* wParam for WM_POWER window message and DRV_POWER driver notification */

    
    #define PWR_FAIL            (-1)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #define WHEEL_PAGESCROLL                (UINT_MAX)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    /*  wParam for WM_SIZING message  */

    
    
    
    
    
    
    
    

    /* WM_NCHITTEST and MOUSEHOOKSTRUCT Mouse Position Codes */

    #define HTERROR             (-2)
    #define HTTRANSPARENT       (-1)
    
    
    
    
    
    #define HTSIZE              HTGROWBOX
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #define HTREDUCE            HTMINBUTTON
    #define HTZOOM              HTMAXBUTTON
    #define HTSIZEFIRST         HTLEFT
    #define HTSIZELAST          HTBOTTOMRIGHT
    
    
    
    
    
    
    
    

    /* WM_MOUSEACTIVATE Return Codes */

    
    
    
    

    /* WM_SETICON / WM_GETICON Type Codes */

    
    

    /* WM_SIZE message wParam values */

    
    
    
    
    

    /* Obsolete constant names */

    #define SIZENORMAL          SIZE_RESTORED
    #define SIZEICONIC          SIZE_MINIMIZED
    #define SIZEFULLSCREEN      SIZE_MAXIMIZED
    #define SIZEZOOMSHOW        SIZE_MAXSHOW
    #define SIZEZOOMHIDE        SIZE_MAXHIDE

    /* WM_NCCALCSIZE "window valid rect" return values */

    
    
    
    
    
    
    #define WVR_REDRAW         (WVR_HREDRAW | \
                                WVR_VREDRAW)

    /* Key State Masks for Mouse Messages */

    
    
    
    
    
    
    
    
    
    
    
    

    /* Window Styles */

    #define WS_OVERLAPPED       0x00000000L
    #define WS_POPUP            0x80000000L
    #define WS_CHILD            0x40000000L
    #define WS_MINIMIZE         0x20000000L
    #define WS_VISIBLE          0x10000000L
    #define WS_DISABLED         0x08000000L
    #define WS_CLIPSIBLINGS     0x04000000L
    #define WS_CLIPCHILDREN     0x02000000L
    #define WS_MAXIMIZE         0x01000000L
    #define WS_CAPTION          0x00C00000L
    #define WS_BORDER           0x00800000L
    #define WS_DLGFRAME         0x00400000L
    #define WS_VSCROLL          0x00200000L
    #define WS_HSCROLL          0x00100000L
    #define WS_SYSMENU          0x00080000L
    #define WS_THICKFRAME       0x00040000L
    #define WS_GROUP            0x00020000L
    #define WS_TABSTOP          0x00010000L
    
    #define WS_MINIMIZEBOX      0x00020000L
    #define WS_MAXIMIZEBOX      0x00010000L

    #define WS_TILED            WS_OVERLAPPED
    #define WS_ICONIC           WS_MINIMIZE
    #define WS_SIZEBOX          WS_THICKFRAME
    #define WS_TILEDWINDOW      WS_OVERLAPPEDWINDOW

    /* Common Window Styles */

    #define WS_OVERLAPPEDWINDOW (WS_OVERLAPPED     | \
                                 WS_CAPTION        | \
                                 WS_SYSMENU        | \
                                 WS_THICKFRAME     | \
                                 WS_MINIMIZEBOX    | \
                                 WS_MAXIMIZEBOX)
    
    #define WS_POPUPWINDOW      (WS_POPUP          | \
                                 WS_BORDER         | \
                                 WS_SYSMENU)
    
    #define WS_CHILDWINDOW      (WS_CHILD)

    /* Extended Window Styles */

    #define WS_EX_DLGMODALFRAME     0x00000001L
    #define WS_EX_NOPARENTNOTIFY    0x00000004L
    #define WS_EX_TOPMOST           0x00000008L
    #define WS_EX_ACCEPTFILES       0x00000010L
    #define WS_EX_TRANSPARENT       0x00000020L
    #define WS_EX_MDICHILD          0x00000040L
    #define WS_EX_TOOLWINDOW        0x00000080L
    #define WS_EX_WINDOWEDGE        0x00000100L
    #define WS_EX_CLIENTEDGE        0x00000200L
    #define WS_EX_CONTEXTHELP       0x00000400L
    #define WS_EX_RIGHT             0x00001000L
    #define WS_EX_LEFT              0x00000000L
    #define WS_EX_RTLREADING        0x00002000L
    #define WS_EX_LTRREADING        0x00000000L
    #define WS_EX_LEFTSCROLLBAR     0x00004000L
    #define WS_EX_RIGHTSCROLLBAR    0x00000000L
    #define WS_EX_CONTROLPARENT     0x00010000L
    #define WS_EX_STATICEDGE        0x00020000L
    #define WS_EX_APPWINDOW         0x00040000L
    #define WS_EX_OVERLAPPEDWINDOW  (WS_EX_WINDOWEDGE | WS_EX_CLIENTEDGE)
    #define WS_EX_PALETTEWINDOW     (WS_EX_WINDOWEDGE | WS_EX_TOOLWINDOW | WS_EX_TOPMOST)

    /* Class styles */

    
    
    
    
    
    
    
    
    
    
    
    
    

    /* Predefined Clipboard Formats */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /* "Private" formats don't get GlobalFree()'d */

    
    

    /* "GDIOBJ" formats do get DeleteObject()'d */

    
    

    /* Menu flags for Add/Check/EnableMenuItem() */

    #define MF_INSERT           0x00000000L
    #define MF_CHANGE           0x00000080L
    #define MF_APPEND           0x00000100L
    #define MF_DELETE           0x00000200L
    #define MF_REMOVE           0x00001000L
    
    #define MF_BYCOMMAND        0x00000000L
    #define MF_BYPOSITION       0x00000400L
    
    #define MF_SEPARATOR        0x00000800L
    
    #define MF_ENABLED          0x00000000L
    #define MF_GRAYED           0x00000001L
    #define MF_DISABLED         0x00000002L
    
    #define MF_UNCHECKED        0x00000000L
    #define MF_CHECKED          0x00000008L
    #define MF_USECHECKBITMAPS  0x00000200L
    
    #define MF_STRING           0x00000000L
    #define MF_BITMAP           0x00000004L
    #define MF_OWNERDRAW        0x00000100L
    
    #define MF_POPUP            0x00000010L
    #define MF_MENUBARBREAK     0x00000020L
    #define MF_MENUBREAK        0x00000040L
    
    #define MF_UNHILITE         0x00000000L
    #define MF_HILITE           0x00000080L
    
    #define MF_DEFAULT          0x00001000L
    #define MF_SYSMENU          0x00002000L
    #define MF_HELP             0x00004000L
    #define MF_RIGHTJUSTIFY     0x00004000L
    
    #define MF_MOUSESELECT      0x00008000L
    #define MF_END              0x00000080L
    
    #define MFT_STRING          MF_STRING
    #define MFT_BITMAP          MF_BITMAP
    #define MFT_MENUBARBREAK    MF_MENUBARBREAK
    #define MFT_MENUBREAK       MF_MENUBREAK
    #define MFT_OWNERDRAW       MF_OWNERDRAW
    #define MFT_RADIOCHECK      0x00000200L
    #define MFT_SEPARATOR       MF_SEPARATOR
    #define MFT_RIGHTORDER      0x00002000L
    #define MFT_RIGHTJUSTIFY    MF_RIGHTJUSTIFY
    
    /* Menu flags for Add/Check/EnableMenuItem() */

    #define MFS_GRAYED          0x00000003L
    #define MFS_DISABLED        MFS_GRAYED
    #define MFS_CHECKED         MF_CHECKED
    #define MFS_HILITE          MF_HILITE
    #define MFS_ENABLED         MF_ENABLED
    #define MFS_UNCHECKED       MF_UNCHECKED
    #define MFS_UNHILITE        MF_UNHILITE
    #define MFS_DEFAULT         MF_DEFAULT
    #define MFS_MASK            0x0000108BL
    #define MFS_HOTTRACKDRAWN   0x10000000L
    #define MFS_CACHEDBMP       0x20000000L
    #define MFS_BOTTOMGAPDROP   0x40000000L
    #define MFS_TOPGAPDROP      0x80000000L
    #define MFS_GAPDROP         0xC0000000L
    
    #define MF_END             0x00000080L

    /* System Menu Command Values */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /* Obsolete names */

    #define SC_ICON         SC_MINIMIZE
    #define SC_ZOOM         SC_MAXIMIZE

    /* OEM Resource Ordinal Numbers */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #define OIC_WARNING         OIC_BANG
    #define OIC_ERROR           OIC_HAND
    #define OIC_INFORMATION     OIC_NOTE

    /* Standard Icon IDs */

    
    
    
    
    
    
    
    #define IDI_WARNING     IDI_EXCLAMATION
    #define IDI_ERROR       IDI_HAND
    #define IDI_INFORMATION IDI_ASTERISK

    /* Dialog Box Command IDs */

    
    
    
    
    
    
    
    
    
    
    /* Edit Control Styles */

    #define ES_LEFT             0x0000L
    #define ES_CENTER           0x0001L
    #define ES_RIGHT            0x0002L
    #define ES_MULTILINE        0x0004L
    #define ES_UPPERCASE        0x0008L
    #define ES_LOWERCASE        0x0010L
    #define ES_PASSWORD         0x0020L
    #define ES_AUTOVSCROLL      0x0040L
    #define ES_AUTOHSCROLL      0x0080L
    #define ES_NOHIDESEL        0x0100L
    #define ES_OEMCONVERT       0x0400L
    #define ES_READONLY         0x0800L
    #define ES_WANTRETURN       0x1000L
    #define ES_NUMBER           0x2000L
    
    /* Edit Control Messages */

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    #define EM_SETLIMITTEXT         EM_LIMITTEXT
    
    
    
    
    
    
    
    /* Button Control Styles */

    #define BS_PUSHBUTTON       0x00000000L
    #define BS_DEFPUSHBUTTON    0x00000001L
    #define BS_CHECKBOX         0x00000002L
    #define BS_AUTOCHECKBOX     0x00000003L
    #define BS_RADIOBUTTON      0x00000004L
    #define BS_3STATE           0x00000005L
    #define BS_AUTO3STATE       0x00000006L
    #define BS_GROUPBOX         0x00000007L
    #define BS_USERBUTTON       0x00000008L
    #define BS_AUTORADIOBUTTON  0x00000009L
    #define BS_OWNERDRAW        0x0000000BL
    #define BS_LEFTTEXT         0x00000020L
    #define BS_TEXT             0x00000000L
    #define BS_ICON             0x00000040L
    #define BS_BITMAP           0x00000080L
    #define BS_LEFT             0x00000100L
    #define BS_RIGHT            0x00000200L
    #define BS_CENTER           0x00000300L
    #define BS_TOP              0x00000400L
    #define BS_BOTTOM           0x00000800L
    #define BS_VCENTER          0x00000C00L
    #define BS_PUSHLIKE         0x00001000L
    #define BS_MULTILINE        0x00002000L
    #define BS_NOTIFY           0x00004000L
    #define BS_FLAT             0x00008000L
    #define BS_RIGHTBUTTON      BS_LEFTTEXT

    /* User Button Notification Codes */

    
    
    
    
    
    
    #define BN_PUSHED           BN_HILITE
    #define BN_UNPUSHED         BN_UNHILITE
    #define BN_DBLCLK           BN_DOUBLECLICKED
    
    

    /* Button Control Messages */

    
    
    
    
    
    
    
    
    
    
    
    
    
    

    /* Static Control Constants */

    #define SS_LEFT             0x00000000L
    #define SS_CENTER           0x00000001L
    #define SS_RIGHT            0x00000002L
    #define SS_ICON             0x00000003L
    #define SS_BLACKRECT        0x00000004L
    #define SS_GRAYRECT         0x00000005L
    #define SS_WHITERECT        0x00000006L
    #define SS_BLACKFRAME       0x00000007L
    #define SS_GRAYFRAME        0x00000008L
    #define SS_WHITEFRAME       0x00000009L
    #define SS_USERITEM         0x0000000AL
    #define SS_SIMPLE           0x0000000BL
    #define SS_LEFTNOWORDWRAP   0x0000000CL
    #define SS_OWNERDRAW        0x0000000DL
    #define SS_BITMAP           0x0000000EL
    #define SS_ENHMETAFILE      0x0000000FL
    #define SS_ETCHEDHORZ       0x00000010L
    #define SS_ETCHEDVERT       0x00000011L
    #define SS_ETCHEDFRAME      0x00000012L
    #define SS_TYPEMASK         0x0000001FL
    #define SS_NOPREFIX         0x00000080L
    #define SS_NOTIFY           0x00000100L
    #define SS_CENTERIMAGE      0x00000200L
    #define SS_RIGHTJUST        0x00000400L
    #define SS_REALSIZEIMAGE    0x00000800L
    #define SS_SUNKEN           0x00001000L
    #define SS_ENDELLIPSIS      0x00004000L
    #define SS_PATHELLIPSIS     0x00008000L
    #define SS_WORDELLIPSIS     0x0000C000L
    #define SS_ELLIPSISMASK     0x0000C000L

    /* Dialog Styles */

    #define DS_ABSALIGN         0x01L
    #define DS_SYSMODAL         0x02L
    #define DS_LOCALEDIT        0x20L
    #define DS_SETFONT          0x40L
    #define DS_MODALFRAME       0x80L
    #define DS_NOIDLEMSG        0x100L
    #define DS_SETFOREGROUND    0x200L
    
    #define DS_3DLOOK           	0x0004L
    #define DS_FIXEDSYS         	0x0008L
    #define DS_NOFAILCREATE     	0x0010L
    #define DS_CONTROL          	0x0400L
    #define DS_CENTER           	0x0800L
    #define DS_CENTERMOUSE      	0x1000L
    #define DS_CONTEXTHELP      	0x2000L

    /* Listbox Styles */

    #define LBS_NOTIFY            0x0001L
    #define LBS_SORT              0x0002L
    #define LBS_NOREDRAW          0x0004L
    #define LBS_MULTIPLESEL       0x0008L
    #define LBS_OWNERDRAWFIXED    0x0010L
    #define LBS_OWNERDRAWVARIABLE 0x0020L
    #define LBS_HASSTRINGS        0x0040L
    #define LBS_USETABSTOPS       0x0080L
    #define LBS_NOINTEGRALHEIGHT  0x0100L
    #define LBS_MULTICOLUMN       0x0200L
    #define LBS_WANTKEYBOARDINPUT 0x0400L
    #define LBS_EXTENDEDSEL       0x0800L
    #define LBS_DISABLENOSCROLL   0x1000L
    #define LBS_NODATA            0x2000L
    #define LBS_NOSEL             0x4000L
    #define LBS_STANDARD          (LBS_NOTIFY | LBS_SORT | WS_VSCROLL | WS_BORDER)

    /* Combo Box styles */

    #define CBS_SIMPLE            	0x0001L
    #define CBS_DROPDOWN          	0x0002L
    #define CBS_DROPDOWNLIST      	0x0003L
    #define CBS_OWNERDRAWFIXED    	0x0010L
    #define CBS_OWNERDRAWVARIABLE 	0x0020L
    #define CBS_AUTOHSCROLL       	0x0040L
    #define CBS_OEMCONVERT        	0x0080L
    #define CBS_SORT              	0x0100L
    #define CBS_HASSTRINGS        	0x0200L
    #define CBS_NOINTEGRALHEIGHT  	0x0400L
    #define CBS_DISABLENOSCROLL   	0x0800L
    #define CBS_UPPERCASE           0x2000L
    #define CBS_LOWERCASE           0x4000L

    /* Scroll Bar Styles */

    #define SBS_HORZ                    0x0000L
    #define SBS_VERT                    0x0001L
    #define SBS_TOPALIGN                0x0002L
    #define SBS_LEFTALIGN               0x0002L
    #define SBS_BOTTOMALIGN             0x0004L
    #define SBS_RIGHTALIGN              0x0004L
    #define SBS_SIZEBOXTOPLEFTALIGN     0x0002L
    #define SBS_SIZEBOXBOTTOMRIGHTALIGN 0x0004L
    #define SBS_SIZEBOX                 0x0008L
    #define SBS_SIZEGRIP                0x0010L

    /* Commands to pass to WinHelp() */

    #define HELP_CONTEXT      0x0001L
    #define HELP_QUIT         0x0002L
    #define HELP_INDEX        0x0003L
    #define HELP_CONTENTS     0x0003L
    #define HELP_HELPONHELP   0x0004L
    #define HELP_SETINDEX     0x0005L
    #define HELP_SETCONTENTS  0x0005L
    #define HELP_CONTEXTPOPUP 0x0008L
    #define HELP_FORCEFILE    0x0009L
    #define HELP_KEY          0x0101L
    #define HELP_COMMAND      0x0102L
    #define HELP_PARTIALKEY   0x0105L
    #define HELP_MULTIKEY     0x0201L
    #define HELP_SETWINPOS    0x0203L
    
    
    
    
    
    
    
    
    
    /* These are in winhelp.h in Win95. */

    
    
    
    
    
    
    
    
    









#define IDR_MENU                                      32000

#define IDC_BUTTON1                                   40000

#define IDC_BUTTON2                                    3001
#define IDC_BUTTON3                                    3002
#define IDC_BUTTON4                                    3003
#define IDC_BUTTON5                                    3004
#define IDC_BUTTON6                                    3005
#define IDC_BUTTON7                                    3006
#define IDC_BUTTON8                                    3007
#define IDC_BUTTON9                                    3008
#define IDC_BUTTON10                                   3009
#define IDC_BUTTON11                                   3010
#define IDC_BUTTON12                                   3011
#define IDC_BUTTON13                                   3012
#define IDC_BUTTON14                                   3013
#define IDC_BUTTON15                                   3014
#define IDC_BUTTON16                                   3015
#define IDC_BUTTON17                                   3016
#define IDC_BUTTON18                                   3017
#define IDC_BUTTON19                                   3018
#define IDC_BUTTON20                                   3019
#define IDC_BUTTON21                                   3020
#define IDC_BUTTON22                                   3021
#define IDC_BUTTON23                                   3022
#define IDC_BUTTON24                                   3023
#define IDC_BUTTON25                                   3024
#define IDC_BUTTON26                                   3025
#define IDC_BUTTON27                                   3026
#define IDC_BUTTON28                                   3027
#define IDC_BUTTON29                                   3028
#define IDC_BUTTON30                                   3029
#define IDC_BUTTON31                                   3030
#define IDC_BUTTON32                                   3031
#define IDC_BUTTON33                                   3032
#define IDC_BUTTON34                                   3033
#define IDC_BUTTON35                                   3034
#define IDC_BUTTON36                                   3035
#define IDC_BUTTON37                                   3036
#define IDC_BUTTON38                                   3037
#define IDC_BUTTON39                                   3038
#define IDC_BUTTON40                                   3039
#define IDC_BUTTON41                                   3040
#define IDC_BUTTON42                                   3041
#define IDC_BUTTON43                                   3042
#define IDC_BUTTON44                                   3043
#define IDC_BUTTON45                                   3044
#define IDC_BUTTON46                                   3045
#define IDC_BUTTON47                                   3046
#define IDC_BUTTON48                                   3047
#define IDC_BUTTON49                                   3048

#define IDC_RADIO1                                     3000
#define IDC_RADIO2                                     3050
#define IDC_RADIO5                                     3053
#define IDC_RADIO6                                     3054
#define IDC_RADIO7                                     3055
#define IDC_RADIO8                                     3056
#define IDC_RADIO9                                     3057
#define IDC_RADIO10                                    3058
#define IDC_EDIT2                                      3062
#define IDC_EDIT3                                      3063
#define IDC_EDIT4                                      3064
#define IDC_EDIT5                                      3065
#define IDC_EDIT6                                      3066
#define IDC_EDIT7                                      3067
#define IDC_EDIT8                                      3068
#define IDC_EDIT9                                      3069
#define IDC_EDIT10                                     3070
#define IDC_EDIT11                                     3071
#define IDC_EDIT12                                     3072
#define IDC_EDIT13                                     3073
#define IDC_EDIT14                                     3074
#define IDC_EDIT15                                     3075
#define IDC_EDIT16                                     3076
#define IDC_EDIT17                                     3077
#define IDC_EDIT18                                     3078
#define IDC_EDIT19                                     3079
#define IDC_EDIT20                                     3080
#define IDC_EDIT21                                     3081
#define IDC_EDIT22                                     3082
#define IDC_EDIT23                                     3083
#define IDC_EDIT24                                     3084
#define IDC_STATIC                                       -1
#define IDC_TERMIN                                     3059
#define IDB_BITMAP1                                     110
#define IDM_ITEM1                                     32002
#define IDM_ITEM2                                     32006
#define IDC_UPDOWN2                                     103
#define IDC_UPDOWN3                                     104
#define IDC_UPDOWN4                                     105
#define IDC_UPDOWN5                                     106
#define IDC_UPDOWN6                                     107
#define IDC_UPDOWN7                                     108
#define IDC_UPDOWN8                                     109
#define IDC_UPDOWN9                                     110
#define IDC_UPDOWN10                                    111
#define IDC_UPDOWN11                                    112
#define IDC_UPDOWN12                                    113
#define IDC_UPDOWN13                                    114
#define IDC_UPDOWN14                                    115
#define IDC_UPDOWN15                                    116
#define IDC_UPDOWN16                                    117
#define IDC_UPDOWN17                                    118
#define IDC_UPDOWN18                                    119
#define IDC_UPDOWN19                                    120
#define IDC_UPDOWN20                                    121
#define IDC_UPDOWN21                                    122
#define IDC_UPDOWN22                                    123
#define IDC_UPDOWN23                                    124
#define IDC_UPDOWN24                                    125
#define IDC_UPDOWN25                                    126
#define IDC_UPDOWN26                                    127
